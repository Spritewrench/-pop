<script type="text/javascript">
var Clay = Clay || {};
Clay.gameKey = "410BYvFMiu3U9ZVOzZFN5Yq8pjDHrE";
Clay.readyFunctions = [];
Clay.ready = function( fn ) {
    Clay.readyFunctions.push( fn );
};
( function() {
    var clay = document.createElement("script"); clay.async = true;
    clay.src = ( "https:" == document.location.protocol ? "https://" : "http://" ) + "clay.io/api/api.js"; 
    var tag = document.getElementsByTagName("script")[0]; tag.parentNode.insertBefore(clay, tag);
} )();


  
</script>